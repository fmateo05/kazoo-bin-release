<?php
    header("content-type: text/xml");
    echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
?>
<Response>
    <Dial>
        <User>
128d81866e595be608a51e51e03be2ac
        </User>
    </Dial>
    <Say>Goodbye</Say>
</Response>