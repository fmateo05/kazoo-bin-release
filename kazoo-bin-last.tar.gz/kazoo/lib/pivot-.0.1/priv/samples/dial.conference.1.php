<?php
    header("content-type: text/xml");
    echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
?>
<Response>
  <Dial>
   <Conference>Room 1234</Conference>
  </Dial>
</Response>