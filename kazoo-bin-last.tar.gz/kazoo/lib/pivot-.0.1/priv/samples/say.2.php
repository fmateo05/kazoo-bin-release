<?php
    header("content-type: text/xml");
    echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
?>
<Response>
     <Say voice="woman" language="en-gb" loop="2">Hello</Say>
</Response>