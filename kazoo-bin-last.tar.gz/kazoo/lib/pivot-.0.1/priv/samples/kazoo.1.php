<?php
    header("content-type: application/json");
?>
{
   "data": {
       "id": "128d81866e595be608a51e51e03be2ac",
       "timeout": "20",
       "can_call_self": false
   },
   "module": "user",
   "children": {
       "_": {
           "data": {
               "id": "9afa4973c3b4440f522955fc026c33a9"
           },
           "module": "voicemail",
           "children": {
           }
       }
   }
}